var express  = require('express');
var router = express.Router();
var Comment = require('../models/Comment');
var Post = require('../models/Post');
var util = require('../util');

// Index
router.get('/', function(req, res){
  Comment.find({})                  // 1
  .sort('-createdAt')            // 1
  .exec(function(err, posts){    // 1
    if(err) return res.json(err);
    res.render('posts/index', {comments:comments});
  });
});

// New
// router.get('/new', function(req, res){
//   res.render('posts/new');
// });

// create
router.post('/', function(req, res){
  Comment.create(req.body, function(err, comment){
    if(err) return res.json(err);
    res.redirect('/posts');
  });
});

// show
// router.get('/:id', function(req, res){
//   Post.findOne({_id:req.params.id}, function(err, post){
//     if(err) return res.json(err);
//     res.render('posts/show', {post:post});
//   });
// });

// edit
router.get('/:id/edit', function(req, res){
  Post.findOne({_id:req.params.id}, function(err, post){
    if(err) return res.json(err);

    res.render('posts/edit', {post:post});
  });
});

// update

router.put('/:id', async(req, res) => {
  const {content} = req.body.body;
  const spassword = req.body.password;
  const opassword = await Post.findOne({_id:req.params.id});
  if(opassword['password'] == spassword){
    Post.findOneAndUpdate({_id:req.params.id}, req.body, function(err, post){
    if(err) return res.json(err);
    res.redirect("/posts/"+req.params.id);
  })}
    else {
          res.write("<script>alert('password is wrong')</script>");
          res.write("<script>window.location=\"../posts\"</script>");
        };
})

router.delete('/:id', async(req, res) => {
  const spassword = req.body.password
  const opassword = await Post.findOne({_id:req.params.id});
  if(opassword['password'] == spassword){
    Post.deleteOne({_id:req.params.id}, req.body, function(err, post){
    if(err) return res.json(err);
    res.redirect("/posts/"+req.params.id);
  })}
    else {
          res.write("<script>alert('password is wrong')</script>");
          res.write("<script>window.location=\"posts\"</script>");
        };
})

module.exports = router;

// private functions
function checkPostId(req, res, next){ // 1
    Post.findOne({_id:req.query.postId},function(err, post){
      if(err) return res.json(err);
  
      res.locals.post = post; // 1-1
      next();
    });
  }