// models/Post.js

var mongoose = require('mongoose');

// schema
var commentSchema = mongoose.Schema({ // 1
  id:{type:String, required:true},
  comment:{type:String, required:true},
  createdAt:{type:Date, default:Date.now}
});

// model & export
var Comment = mongoose.model('comment', commentSchema);
module.exports = Post;
